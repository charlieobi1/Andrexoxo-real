import { readFileSync, writeFileSync, existsSync, mkdirSync } from "fs";
import { join } from "path";
import { logger } from "./lib/logger.js";

const DATA_DIR = join(process.cwd(), ".bot-data");
const MEMORY_FILE = join(DATA_DIR, "memories.json");

type UserMemories = Record<string, string[]>;

function ensureDataDir() {
  if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });
}

function loadAll(): UserMemories {
  try {
    ensureDataDir();
    if (!existsSync(MEMORY_FILE)) return {};
    return JSON.parse(readFileSync(MEMORY_FILE, "utf-8")) as UserMemories;
  } catch (err) {
    logger.error({ err }, "Failed to load memories");
    return {};
  }
}

function saveAll(data: UserMemories) {
  try {
    ensureDataDir();
    writeFileSync(MEMORY_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    logger.error({ err }, "Failed to save memories");
  }
}

export function getMemories(userId: number): string[] {
  const all = loadAll();
  return all[String(userId)] ?? [];
}

export function addMemory(userId: number, fact: string): void {
  const all = loadAll();
  const key = String(userId);
  if (!all[key]) all[key] = [];
  all[key].push(fact.trim());
  saveAll(all);
}

export function clearMemories(userId: number): void {
  const all = loadAll();
  delete all[String(userId)];
  saveAll(all);
}
