import express from "express";
import { logger } from "./lib/logger.js";
import { createBot, BOT_COMMANDS } from "./bot.js";

const port = Number(process.env["PORT"] ?? 3000);

const app = express();
app.get("/healthz", (_req, res) => res.json({ status: "ok" }));

app.listen(port, () => {
  logger.info({ port }, "Server listening");
});

const bot = createBot();

bot.launch().then(async () => {
  logger.info("Telegram bot started (long polling)");
  await bot.telegram.setMyCommands(BOT_COMMANDS);
  logger.info("Telegram command menu registered");
}).catch((err) => {
  logger.error({ err }, "Failed to start Telegram bot");
  process.exit(1);
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
