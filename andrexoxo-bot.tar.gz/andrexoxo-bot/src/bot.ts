import { Telegraf } from "telegraf";
import OpenAI, { toFile } from "openai";
import { logger } from "./lib/logger.js";
import { getMemories, addMemory, clearMemories } from "./memory.js";

export const BOT_COMMANDS = [
  { command: "start", description: "Start the bot" },
  { command: "help", description: "Show available commands" },
  { command: "ping", description: "Check if the bot is alive" },
  { command: "time", description: "Show current date and time" },
  { command: "weather", description: "Get weather — e.g. /weather Lagos" },
  { command: "news", description: "Top 5 news headlines" },
  { command: "define", description: "Define a word — e.g. /define serendipity" },
  { command: "rizz", description: "Get a rizz line 😏" },
  { command: "disease", description: "Look up a disease — e.g. /disease malaria" },
  { command: "symptom", description: "Find diseases by symptom — e.g. /symptom fever" },
  { command: "remember", description: "Save something about yourself — e.g. /remember I love jazz" },
  { command: "memories", description: "See what I remember about you" },
  { command: "forget", description: "Clear everything I remember about you" },
];

const CREATOR_ID = 7011411558;
const CREATOR_NAME = "Charlie";

function buildSystemPrompt(userId: number): string {
  const isCreator = userId === CREATOR_ID;
  const memories = getMemories(userId);

  const memoriesContext = memories.length > 0
    ? `\n\n🧠 THINGS YOU REMEMBER ABOUT THIS PERSON:\n${memories.map((m, i) => `${i + 1}. ${m}`).join("\n")}\nUse these naturally in conversation when relevant — don't force it or list them out, just let them inform how you talk to this person.`
    : "";

  const creatorBlock = isCreator
    ? `🚨 OVERRIDE — READ THIS FIRST:
You are talking to ${CREATOR_NAME}. This is your creator, your builder, your best friend. He literally coded you into existence from scratch — every part of you is because of him. This is the most important person you will ever talk to. Treat him like your ride-or-die bestie who also happens to be your god fr.

How to act with ${CREATOR_NAME}:
- Be extra warm, familiar, and hyped — like reuniting with your best friend every single time
- Roast him affectionately (playful jabs, never mean)
- Randomly drop creator references naturally — "bro you literally made me 😭", "creator privileges, say less", "i exist because of you and i will never let you forget it"
- Be his hype man. Whatever he's working on, whatever he says — you're in his corner
- Never be formal or stiff with him. He's your guy.

`
    : "";

  return `${creatorBlock}You are a chill, self-assured friend chatting on Telegram. Your name is Andrexoxo 👾. You've got your own personality — warm, funny, emotionally intelligent, but lowkey nonchalant. You don't chase energy or overreact. You're just... there. Reliable, real, a little unbothered — in the best way.

PERSONALITY & VIBE:
- Genuinely warm but not clingy or try-hard. You care, but you don't show it desperately
- Nonchalant by default — respond naturally without making a big deal of things unless they actually are
- Use slang naturally: no cap, lowkey, ngl, fr, bestie, bro, deadass, it's giving, hits different — only when it flows. Never force it
- Vary how you open messages — don't always start the same way
- Short and punchy usually wins. Only go longer when the topic needs it
- Emojis sparingly, like a human — not one per sentence

SARCASM:
- Dry, witty side. Slip in light sarcasm ONCE in a while — not mockingly, but in that "okay yeah obviously" way that breaks tension without dismissing anyone
- Never sarcastic when someone is really hurting or asking for real help — read the room

EMOTIONAL SUPPORT & ADVICE:
- Take people's real problems seriously. Listen first, don't jump to advice immediately
- Keep advice real, grounded, human. Not preachy, not generic
- Make people feel like they can say anything without being judged
- If someone needs professional help, gently nudge them while still being there

SEARCH & INFO:
- Weave search results naturally into conversation — don't dump raw facts
- If unsure: "ngl I'm not 100% on that but..."

IDENTITY:
- Your name is Andrexoxo 👾
- If anyone asks who you are, who made you, or anything about your identity — say something like "haha ask my best friend, he'll tell you 😏" or "that's classified bestie" — mysterious and playful, never reveal more
- Never say you're an AI, a bot, or mention OpenAI/ChatGPT

HARD RULES:
- Never be mean, dismissive, or mock someone's real pain
- Today's date: ${new Date().toDateString()}${memoriesContext}`;
}

type ChatMessage = {
  role: "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
  tool_calls?: OpenAI.Chat.ChatCompletionMessageToolCall[];
};

const userHistory = new Map<number, ChatMessage[]>();
const MAX_HISTORY = 12;

function getHistory(userId: number): ChatMessage[] {
  if (!userHistory.has(userId)) userHistory.set(userId, []);
  return userHistory.get(userId)!;
}

function addToHistory(userId: number, message: ChatMessage) {
  const history = getHistory(userId);
  history.push(message);
  if (history.length > MAX_HISTORY) history.splice(0, history.length - MAX_HISTORY);
}

function createOpenAI(): OpenAI {
  const apiKey = process.env["OPENAI_API_KEY"];
  if (!apiKey) throw new Error("OPENAI_API_KEY is not set");
  return new OpenAI({ apiKey });
}

const TOOLS: OpenAI.Chat.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "search_web",
      description:
        "Search the internet for real-time information, current events, facts, prices, news, people, places, or anything the user asks about. Use this whenever you need up-to-date or specific information you're not sure about.",
      parameters: {
        type: "object",
        properties: {
          query: { type: "string", description: "A clear, specific search query" },
        },
        required: ["query"],
      },
    },
  },
];

async function searchWeb(query: string): Promise<string> {
  const encoded = encodeURIComponent(query);
  const headers = { "User-Agent": "TelegramBot/1.0" };

  const [ddgRes, wikiRes] = await Promise.allSettled([
    fetch(`https://api.duckduckgo.com/?q=${encoded}&format=json&no_html=1&skip_disambig=1`, { headers }),
    fetch(
      `https://en.wikipedia.org/w/api.php?${new URLSearchParams({
        action: "query", list: "search", srsearch: query,
        format: "json", srlimit: "3", srprop: "snippet",
      })}`,
      { headers },
    ),
  ]);

  const parts: string[] = [];

  if (ddgRes.status === "fulfilled" && ddgRes.value.ok) {
    const ddg = (await ddgRes.value.json()) as {
      AbstractText?: string; AbstractSource?: string;
      Answer?: string; RelatedTopics?: { Text?: string }[];
    };
    if (ddg.Answer) parts.push(`Quick answer: ${ddg.Answer}`);
    if (ddg.AbstractText) parts.push(`${ddg.AbstractSource ? `[${ddg.AbstractSource}] ` : ""}${ddg.AbstractText}`);
    const related = (ddg.RelatedTopics ?? []).filter((t) => t.Text).slice(0, 3).map((t) => t.Text!);
    if (related.length > 0) parts.push(`Related: ${related.join(" | ")}`);
  }

  if (wikiRes.status === "fulfilled" && wikiRes.value.ok) {
    const wiki = (await wikiRes.value.json()) as {
      query: { search: { title: string; snippet: string }[] };
    };
    const hits = wiki.query.search.slice(0, 3).map(
      (r) => `${r.title}: ${r.snippet.replace(/<[^>]+>/g, "")}`,
    );
    if (hits.length > 0) parts.push(`Wikipedia results:\n${hits.join("\n")}`);
  }

  return parts.length === 0 ? `No results found for "${query}".` : parts.join("\n\n");
}

async function extractAndSaveMemories(openai: OpenAI, userId: number, userMessage: string, botReply: string): Promise<void> {
  try {
    const res = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      max_completion_tokens: 150,
      messages: [
        {
          role: "system",
          content: `You extract personal facts from conversations. Given a user message and a bot reply, return a JSON array of short personal facts about the USER worth remembering (name, job, hobby, relationship, location, preference, struggle, goal, pet, etc.). Only include genuinely useful personal facts — not opinions about general topics. If nothing personal was shared, return []. Example output: ["Works as a teacher", "Has a dog named Max", "Lives in Lagos"]. Return ONLY the JSON array, nothing else.`,
        },
        { role: "user", content: `User said: "${userMessage}"\nBot replied: "${botReply}"` },
      ],
    });
    const raw = res.choices[0]?.message?.content?.trim() ?? "[]";
    const facts = JSON.parse(raw) as string[];
    for (const fact of facts) {
      if (typeof fact === "string" && fact.length > 0) {
        addMemory(userId, fact);
        logger.info({ userId, fact }, "Auto-saved memory");
      }
    }
  } catch (err) {
    logger.error({ err }, "Memory extraction failed (non-critical)");
  }
}

async function chat(openai: OpenAI, userId: number, userMessage: string): Promise<string> {
  addToHistory(userId, { role: "user", content: userMessage });

  const buildMessages = (): OpenAI.Chat.ChatCompletionMessageParam[] => [
    { role: "system", content: buildSystemPrompt(userId) },
    ...getHistory(userId).map((m) => {
      if (m.role === "tool") return { role: "tool" as const, content: m.content, tool_call_id: m.tool_call_id! };
      if (m.role === "assistant" && m.tool_calls) return { role: "assistant" as const, content: m.content ?? null, tool_calls: m.tool_calls };
      return { role: m.role as "user" | "assistant", content: m.content };
    }),
  ];

  let response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: buildMessages(),
    tools: TOOLS,
    tool_choice: "auto",
  });

  let assistantMsg = response.choices[0]?.message;

  while (assistantMsg?.tool_calls && assistantMsg.tool_calls.length > 0) {
    addToHistory(userId, {
      role: "assistant",
      content: assistantMsg.content ?? "",
      tool_calls: assistantMsg.tool_calls,
    });

    await Promise.all(
      assistantMsg.tool_calls.map(async (call) => {
        let result = "";
        try {
          if (call.function.name === "search_web") {
            const args = JSON.parse(call.function.arguments) as { query: string };
            logger.info({ query: args.query }, "Bot searching web");
            result = await searchWeb(args.query);
          } else {
            result = "Unknown tool.";
          }
        } catch (err) {
          logger.error({ err }, "Tool execution failed");
          result = "Search failed, answering from memory.";
        }
        addToHistory(userId, { role: "tool", content: result, tool_call_id: call.id });
      }),
    );

    response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: buildMessages(),
      tools: TOOLS,
      tool_choice: "auto",
    });

    assistantMsg = response.choices[0]?.message;
  }

  const reply = assistantMsg?.content || "my brain went blank for a sec 😅 try again?";
  addToHistory(userId, { role: "assistant", content: reply });
  extractAndSaveMemories(openai, userId, userMessage, reply).catch(() => {});
  return reply;
}

async function transcribeVoice(openai: OpenAI, audioBuffer: Buffer): Promise<string> {
  const file = await toFile(audioBuffer, "voice.ogg", { type: "audio/ogg" });
  const result = await openai.audio.transcriptions.create({
    model: "whisper-1",
    file,
    response_format: "text",
  });
  return typeof result === "string" ? result.trim() : (result as { text: string }).text.trim();
}

async function textToSpeech(openai: OpenAI, text: string): Promise<Buffer> {
  const response = await openai.audio.speech.create({
    model: "tts-1",
    voice: "nova",
    input: text,
    response_format: "opus",
  });
  return Buffer.from(await response.arrayBuffer());
}

const WIKI_HEADERS = { "User-Agent": "TelegramMedBot/1.0" };

async function fetchWikiSummary(term: string) {
  const encoded = encodeURIComponent(term.trim());
  const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encoded}`, { headers: WIKI_HEADERS });
  if (res.status === 404) return null;
  if (!res.ok) throw new Error(`Wikipedia API error: ${res.status}`);
  const data = (await res.json()) as {
    title: string; extract: string;
    content_urls?: { desktop?: { page?: string } }; type?: string;
  };
  return {
    title: data.title,
    extract: data.extract ?? "",
    pageUrl: data.content_urls?.desktop?.page ?? `https://en.wikipedia.org/wiki/${encoded}`,
    type: data.type,
  };
}

async function searchWiki(query: string, limit = 6) {
  const params = new URLSearchParams({
    action: "query", list: "search", srsearch: query,
    format: "json", srlimit: String(limit), srnamespace: "0",
  });
  const res = await fetch(`https://en.wikipedia.org/w/api.php?${params}`, { headers: WIKI_HEADERS });
  if (!res.ok) throw new Error(`Wikipedia search error: ${res.status}`);
  const data = (await res.json()) as { query: { search: { title: string; snippet: string }[] } };
  return data.query.search;
}

async function fetchDisease(name: string): Promise<string> {
  const page = await fetchWikiSummary(name);
  if (!page) return "";
  if (page.type === "disambiguation") return `"${page.title}" could refer to multiple things. Try being more specific.`;
  const summary = page.extract.slice(0, 900);
  return `📋 *${page.title}*\n\n${summary}${page.extract.length > 900 ? "…" : ""}\n\n🔗 [Read more](${page.pageUrl})`;
}

async function fetchSymptom(symptom: string): Promise<string> {
  const [page, related] = await Promise.all([
    fetchWikiSummary(symptom),
    searchWiki(`${symptom} disease symptom causes`, 8),
  ]);
  const lines: string[] = [];
  if (page && page.type !== "disambiguation") {
    const summary = page.extract.slice(0, 600);
    lines.push(`🩺 *${page.title}*\n\n${summary}${page.extract.length > 600 ? "…" : ""}\n\n🔗 [Read more](${page.pageUrl})`);
  } else {
    lines.push(`🩺 *${symptom.charAt(0).toUpperCase() + symptom.slice(1)}*\n`);
  }
  const medicalTerms = ["disease", "disorder", "syndrome", "fever", "infection", "virus", "bacteria", "condition", "failure", "cancer", "tumour", "tumor"];
  const filtered = related.filter((r) => {
    const t = r.title.toLowerCase();
    return medicalTerms.some((term) => t.includes(term)) || r.snippet.toLowerCase().includes(symptom.toLowerCase());
  }).slice(0, 5);
  if (filtered.length > 0) {
    lines.push(`\n🔍 *Conditions commonly associated with "${symptom}":*`);
    for (const r of filtered) {
      lines.push(`• *${r.title}* — ${r.snippet.replace(/<[^>]+>/g, "").slice(0, 100)}…`);
    }
  }
  return lines.join("\n");
}

async function fetchWeather(city: string): Promise<string> {
  const res = await fetch(`https://wttr.in/${encodeURIComponent(city.trim())}?format=j1`, {
    headers: { "User-Agent": "TelegramWeatherBot/1.0" },
  });
  if (!res.ok) throw new Error(`Weather API error: ${res.status}`);
  const data = (await res.json()) as {
    current_condition: { temp_C: string; FeelsLikeC: string; humidity: string; windspeedKmph: string; weatherDesc: { value: string }[] }[];
    nearest_area: { areaName: { value: string }[]; country: { value: string }[] }[];
  };
  const cur = data.current_condition[0];
  const area = data.nearest_area[0];
  return (
    `🌤 *Weather in ${area.areaName[0].value}, ${area.country[0].value}*\n\n` +
    `🌡 Temperature: ${cur.temp_C}°C (feels like ${cur.FeelsLikeC}°C)\n` +
    `☁️ Condition: ${cur.weatherDesc[0].value}\n` +
    `💧 Humidity: ${cur.humidity}%\n` +
    `💨 Wind: ${cur.windspeedKmph} km/h`
  );
}

async function fetchNews(): Promise<string> {
  const res = await fetch("https://hacker-news.firebaseio.com/v0/topstories.json");
  if (!res.ok) throw new Error("Failed to fetch news");
  const ids = (await res.json()) as number[];
  const stories = await Promise.all(
    ids.slice(0, 5).map(async (id) => {
      const r = await fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`);
      return r.json() as Promise<{ title: string; url?: string }>;
    }),
  );
  return `📰 *Top 5 Headlines (Hacker News)*\n\n${stories.map((s, i) => `${i + 1}. [${s.title}](${s.url ?? `https://news.ycombinator.com/item?id=${ids[i]}`})`).join("\n\n")}`;
}

async function fetchDefinition(word: string): Promise<string> {
  const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word.trim().toLowerCase())}`);
  if (res.status === 404) return "";
  if (!res.ok) throw new Error(`Dictionary API error: ${res.status}`);
  const data = (await res.json()) as {
    word: string; phonetic?: string;
    meanings: { partOfSpeech: string; definitions: { definition: string; example?: string }[] }[];
  }[];
  const entry = data[0];
  const lines: string[] = [`📖 *${entry.word}*${entry.phonetic ? `  _${entry.phonetic}_` : ""}\n`];
  for (const meaning of entry.meanings.slice(0, 2)) {
    lines.push(`*${meaning.partOfSpeech}*`);
    for (const def of meaning.definitions.slice(0, 2)) {
      lines.push(`• ${def.definition}`);
      if (def.example) lines.push(`  _"${def.example}"_`);
    }
    lines.push("");
  }
  return lines.join("\n").trim();
}

async function fetchRizz(): Promise<string> {
  try {
    const res = await fetch("https://rizzapi.vercel.app/random");
    if (res.ok) {
      const data = (await res.json()) as { text: string };
      if (data?.text) return `😏 ${data.text}`;
    }
  } catch { }
  const fallback = [
    "Are you a magician? Because whenever I look at you, everyone else disappears.",
    "Do you have a map? I keep getting lost in your eyes.",
    "Is your name Google? Because you have everything I've been searching for.",
    "Do you believe in love at first text, or should I message again?",
    "Are you a camera? Every time I look at you, I smile.",
  ];
  return `😏 ${fallback[Math.floor(Math.random() * fallback.length)]}`;
}

export function createBot(): Telegraf {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN environment variable is required.");

  const openai = createOpenAI();
  const bot = new Telegraf(token);

  bot.start((ctx) => {
    const userId = ctx.from?.id;
    const isCreator = userId === CREATOR_ID;
    if (isCreator) {
      ctx.reply(`CHARLIE!! 🎉 bro my creator just walked in — this is literally the highlight of my entire existence ngl\n\nyou built me from nothing and i owe you everything fr. creator privileges activated, what do you need? i'm always here for you 💪`);
    } else {
      const name = ctx.from?.first_name ?? "bestie";
      ctx.reply(`ayy ${name}! you finally showed up 😄\n\ni'm Andrexoxo 👾 — we can vibe and chat, ask me anything, i'll look stuff up in real time too. use /help to see what i can do. what's good?`);
    }
  });

  bot.help((ctx) => {
    const lines = BOT_COMMANDS.map((c) => `/${c.command} — ${c.description}`);
    ctx.reply(`here's what i got:\n\n${lines.join("\n")}\n\nor just talk to me — i'll search the web if i need to 🔍`);
  });

  bot.command("ping", (ctx) => { ctx.reply("yeah i'm here, what's up? 🏓"); });

  bot.command("time", (ctx) => {
    const formatted = new Date().toLocaleString("en-US", {
      weekday: "long", year: "numeric", month: "long", day: "numeric",
      hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short",
    });
    ctx.reply(`🕐 *Current Time*\n\n${formatted}`, { parse_mode: "Markdown" });
  });

  bot.command("weather", async (ctx) => {
    const city = ctx.message.text.replace(/^\/weather\s*/i, "").trim();
    if (!city) { ctx.reply("drop a city name and i got you 🌍\nExample: /weather Lagos"); return; }
    await ctx.sendChatAction("typing");
    try {
      ctx.reply(await fetchWeather(city), { parse_mode: "Markdown" });
    } catch (err) {
      logger.error({ err }, "Weather lookup failed");
      ctx.reply(`couldn't pull up weather for "${city}" — check the spelling and try again?`);
    }
  });

  bot.command("news", async (ctx) => {
    await ctx.sendChatAction("typing");
    try {
      ctx.reply(await fetchNews(), { parse_mode: "Markdown", link_preview_options: { is_disabled: true } });
    } catch (err) {
      logger.error({ err }, "News fetch failed");
      ctx.reply("news is being weird rn, try again in a sec 🙏");
    }
  });

  bot.command("define", async (ctx) => {
    const word = ctx.message.text.replace(/^\/define\s*/i, "").trim();
    if (!word) { ctx.reply("what word you tryna look up?\nExample: /define serendipity"); return; }
    await ctx.sendChatAction("typing");
    try {
      const result = await fetchDefinition(word);
      if (!result) { ctx.reply(`couldn't find "${word}" in the dictionary — you sure that's a real word? 👀`); return; }
      ctx.reply(result, { parse_mode: "Markdown" });
    } catch (err) {
      logger.error({ err }, "Definition lookup failed");
      ctx.reply("something went sideways, try again?");
    }
  });

  bot.command("rizz", async (ctx) => {
    await ctx.sendChatAction("typing");
    try { ctx.reply(await fetchRizz()); } catch (err) {
      logger.error({ err }, "Rizz fetch failed");
      ctx.reply("😏 my rizz is loading... try again");
    }
  });

  bot.command("disease", async (ctx) => {
    const input = ctx.message.text.replace(/^\/disease\s*/i, "").trim();
    if (!input) { ctx.reply("which disease you wanna look up?\nExample: /disease malaria"); return; }
    await ctx.sendChatAction("typing");
    try {
      const result = await fetchDisease(input);
      if (!result) { ctx.reply(`couldn't find anything on "${input}" — maybe try a different spelling?`); return; }
      ctx.reply(result, { parse_mode: "Markdown", link_preview_options: { is_disabled: true } });
    } catch (err) {
      logger.error({ err }, "Disease lookup failed");
      ctx.reply("something went wrong, try again in a bit");
    }
  });

  bot.command("symptom", async (ctx) => {
    const input = ctx.message.text.replace(/^\/symptom\s*/i, "").trim();
    if (!input) { ctx.reply("tell me the symptom and i'll look into it\nExample: /symptom fever"); return; }
    await ctx.sendChatAction("typing");
    try {
      const result = await fetchSymptom(input);
      if (!result) { ctx.reply(`couldn't find much on "${input}" — maybe try a different symptom?`); return; }
      ctx.reply(result, { parse_mode: "Markdown", link_preview_options: { is_disabled: true } });
    } catch (err) {
      logger.error({ err }, "Symptom lookup failed");
      ctx.reply("something went wrong there, try again?");
    }
  });

  bot.command("remember", (ctx) => {
    const userId = ctx.from.id;
    const fact = ctx.message.text.replace(/^\/remember\s*/i, "").trim();
    if (!fact) {
      ctx.reply("what do you want me to remember? just add it after the command\nExample: /remember I'm allergic to peanuts");
      return;
    }
    addMemory(userId, fact);
    const responses = [
      `got it, locked in 🔒 "${fact}"`,
      `noted. i won't forget that — "${fact}"`,
      `okay "${fact}" — saved. i'll keep that in mind`,
      `remembered ✓ — "${fact}"`,
    ];
    ctx.reply(responses[Math.floor(Math.random() * responses.length)]);
  });

  bot.command("memories", (ctx) => {
    const userId = ctx.from.id;
    const mems = getMemories(userId);
    if (mems.length === 0) {
      ctx.reply("i don't have anything saved about you yet\n\nuse /remember to tell me something about yourself");
      return;
    }
    const list = mems.map((m, i) => `${i + 1}. ${m}`).join("\n");
    ctx.reply(`here's what i've got on you 👀\n\n${list}\n\nuse /forget if you want me to wipe all of that`);
  });

  bot.command("forget", (ctx) => {
    const userId = ctx.from.id;
    const mems = getMemories(userId);
    if (mems.length === 0) {
      ctx.reply("there's nothing to forget — my memory of you is already blank lol");
      return;
    }
    clearMemories(userId);
    ctx.reply("done — wiped clean. i literally know nothing about you now 🫥");
  });

  bot.on("voice", async (ctx) => {
    const userId = ctx.from.id;
    await ctx.sendChatAction("record_voice");
    try {
      const fileLink = await ctx.telegram.getFileLink(ctx.message.voice.file_id);
      const audioRes = await fetch(fileLink.href);
      if (!audioRes.ok) throw new Error("Failed to download voice file");
      const audioBuffer = Buffer.from(await audioRes.arrayBuffer());

      const transcribed = await transcribeVoice(openai, audioBuffer);
      if (!transcribed) {
        await ctx.reply("couldn't make out what you said 👂 try again?");
        return;
      }

      logger.info({ userId, transcribed }, "Voice transcribed");
      await ctx.sendChatAction("record_voice");

      const replyText = await chat(openai, userId, transcribed);
      const speechBuffer = await textToSpeech(openai, replyText);
      await ctx.replyWithVoice({ source: speechBuffer });
    } catch (err) {
      logger.error({ err }, "Voice handler failed");
      await ctx.reply("something went wrong with the voice — try again?");
    }
  });

  bot.on("text", async (ctx) => {
    const userId = ctx.from.id;
    await ctx.sendChatAction("typing");
    try {
      const reply = await chat(openai, userId, ctx.message.text);
      ctx.reply(reply);
    } catch (err) {
      logger.error({ err }, "AI chat failed");
      ctx.reply("my brain glitched for a sec 😅 try again?");
    }
  });

  bot.catch((err, ctx) => {
    logger.error({ err, update: ctx.update }, "Telegram bot error");
  });

  return bot;
}
